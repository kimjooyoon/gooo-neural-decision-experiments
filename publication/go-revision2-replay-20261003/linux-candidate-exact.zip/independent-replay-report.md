# Revision-2 independent replay in Go

Decision: **PASS**. Physical toolchain: **Go 1.27.1**.

- Original candidates: **93/96** compiled and executed, **3** expected compile failures, **0** unknown.
- Revision-2 candidates: **96/96** compiled and executed, **0** unknown.
- All **32** training suites distinguish the gold candidate from both distractors.
- All **189** result files were removed from temporary copies before execution, freshly produced, and matched their frozen bytes.
- Both saved Go reference suites executed. The Go port of the frozen Python int64 specification checked **228 + 232** finite expected values.
- All **96** Laya plans and **32** external feedback sets were checked as data against the fresh compiled observations.
- Model calls, provider requests and new code generation: **0**. Historical Python files were read as bytes.

Both revisions reuse the same 32 intentions. Candidate compilation and finite behavior are separate counts. Source AST completeness belongs to Gooo's separate receipts. The retained sources and results were unchanged by replay.
