# Go IR composition baseline replay

The original frozen inputs, raw CLI receipts and generated sources were checked with Go 1.27.1.

- Frozen source resolution: 140 exact current files and two explicitly bound historical archives; original freeze unchanged.
- Original source emissions: 22/32; ten missing outputs retain unknown finite expectations.
- Equivalence source emissions: 30/32; two missing outputs retain unknown finite expectations.
- Saved independent modules recompiled and executed: 52/52. These reuse the same 32 intents.
- Original candidate packages: 93/96 compile, with exactly the three preserved expected compile failures.
- The as-run 32/0 source-unit summary is retained; its per-case records reconstruct 30/2. Only the three bound summary fields differ in the correction.
- Model calls, provider requests and new code generation: zero. Historical Python archives were read as bytes.
