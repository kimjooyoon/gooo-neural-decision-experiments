package orderpilot

//gooo:generated:start id="orderpilot://activity/assemble-english" kind="activity"
func AssembleEnglish(input int64) int64 {
	var value = input
	value = (value * 2)
	value = (value + 1)
	return value
}

//gooo:generated:end id="orderpilot://activity/assemble-english" kind="activity"
