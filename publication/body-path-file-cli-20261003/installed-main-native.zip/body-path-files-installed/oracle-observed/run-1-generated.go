package recipe

//gooo:generated:start id="recipe://activity/weave" kind="activity"
func Weave(input int64) int64 {
	var a = (1 - input)
	var b = (3 - a)
	return (9 - b)
}

//gooo:generated:end id="recipe://activity/weave" kind="activity"
