package recipe

//gooo:generated:start id="recipe://activity/weave" kind="activity"
func Weave(input int64) int64 {
	var a = (input - 1)
	var b = (a - 3)
	return (b - 9)
}

//gooo:generated:end id="recipe://activity/weave" kind="activity"
