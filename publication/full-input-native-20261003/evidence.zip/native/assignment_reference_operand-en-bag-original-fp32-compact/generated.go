package threecomposition

//gooo:generated:start id="threecomposition://activity/choose-path" kind="activity"
func ChoosePath(input int64) int64 {
	var localA20 = (input + 1)
	var localB20 = (input * 3)
	localA20 = (localA20 + localB20)
	return (localB20 - localA20)
}

//gooo:generated:end id="threecomposition://activity/choose-path" kind="activity"
