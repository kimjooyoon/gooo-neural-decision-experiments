package threecomposition

//gooo:generated:start id="threecomposition://activity/choose-path" kind="activity"
func ChoosePath(input int64) int64 {
	var localA20 = (input + 1)
	var localB20 = (input * 3)
	if input <= 2 {
		if input == 1 {
			localA20 = (localA20 + localB20)
		} else {
			localB20 = (localA20 - localB20)
		}
	} else {
		localA20 = ((localA20 * 3) + localB20)
		localB20 = (localB20 + 1)
	}
	return ((localB20 + localA20) - localB20)
}

//gooo:generated:end id="threecomposition://activity/choose-path" kind="activity"
