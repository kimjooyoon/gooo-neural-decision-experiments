package bodycodegen

import "testing"

func TestInstalledRawClamp(t *testing.T) {
    cases := []struct{ input, expected int64 }{
        {-9223372036854775808, 0}, {-9223372036854775807, 0}, {-17, 0}, {-1, 0},
        {0, 0}, {1, 1}, {17, 17}, {9223372036854775807, 9223372036854775807},
    }
    for _, item := range cases {
        actual := ClampBelowZero(item.input)
        t.Logf("FINITECLAMP|%d|%d|%d|%t", item.input, item.expected, actual, actual == item.expected)
        if actual != item.expected { t.Errorf("input %d: got %d want %d", item.input, actual, item.expected) }
    }
}
