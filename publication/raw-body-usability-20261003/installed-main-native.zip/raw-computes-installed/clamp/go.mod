module example.invalid/gooo/raw-clamp-installed

go 1.27.1
