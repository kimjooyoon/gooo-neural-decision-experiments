package main

import (
 "bytes"
 "crypto/sha256"
 "encoding/json"
 "fmt"
 "os"
 "path/filepath"
 "sort"
 "strings"

 "github.com/kimjooyoon/gooo-decision-runtime/pathplan"
 "github.com/kimjooyoon/meta-ontology-go/internal/bodyexecution"
 "github.com/kimjooyoon/meta-ontology-go/internal/completeness"
)
func must(e error){if e!=nil{panic(e)}}
func read(p string)[]byte{b,e:=os.ReadFile(p);must(e);return b}
func sha(b []byte)string{return fmt.Sprintf("sha256:%x",sha256.Sum256(b))}
func median(v []float64)float64{sort.Float64s(v);n:=len(v);return(v[(n-1)/2]+v[n/2])/2}
func integer(v any)int{n,e:=v.(json.Number).Int64();must(e);return int(n)}
type binding struct { Metadata string `json:"metadata_sha256"`; Weights string `json:"weights_sha256"`; Schema string `json:"schema"` }
func verifyChains(progress []pathplan.SessionProgress, feedback []pathplan.FeedbackReceipt, pin binding) {
 if len(progress)<2||pin.Metadata==""||pin.Weights==""||pin.Schema==""{panic("missing bound chain")}
 previous:="";observed:=map[string]pathplan.SessionProgress{}
 for i,p:=range progress{
  original:=p.SHA;p.SHA="";raw,e:=json.Marshal(p);must(e)
  if original!=strings.TrimPrefix(sha(raw),"sha256:")||p.Sequence!=i+1||p.PreviousSHA!=previous||p.Selection.MetadataSHA256!=pin.Metadata||p.Selection.WeightsSHA256!=pin.Weights||p.Selection.Three==nil||p.Selection.Three.Schema!=pin.Schema{panic("progress chain or model identity differs")}
  observed[original]=p;previous=original
 }
 previous="";calls:=1
 for i,f:=range feedback{
  original:=f.SHA;f.SHA="";raw,e:=json.Marshal(f);must(e);parent,ok:=observed[f.FromProgressSHA]
  calls+=f.ModelCalls
  if original!=strings.TrimPrefix(sha(raw),"sha256:")||f.Round!=i+1||f.PreviousSHA!=previous||!ok||parent.CaseSHA!=f.CaseSHA||parent.Selection.PlanSHA256!=f.PlanSHA||parent.Attempted!=f.Attempted||f.MetadataSHA!=pin.Metadata||f.WeightsSHA!=pin.Weights||f.CumulativeCalls!=calls||f.CIIsAuthority {panic("feedback chain or model accounting differs")}
  if f.Three!=nil&&f.Three.Schema!=pin.Schema{panic("feedback schema differs")}
  previous=original
 }
 last:=progress[len(progress)-1]
 if last.LatestFeedbackSHA!=previous||last.FeedbackRounds!=len(feedback)||last.Selection.ModelCalls!=calls{panic("terminal chain differs")}
}
func main(){
 if len(os.Args)!=2{panic("runtime-capture directory required")};root:=os.Args[1]
 paths,e:=filepath.Glob(filepath.Join(root,"*","runtime.json"));must(e);if len(paths)!=96{panic("expected 96 runtime receipts")}
 var pre struct { Compact struct { Bindings map[string]binding `json:"model_bindings"` } `json:"compact_comparison"` };must(json.Unmarshal(read(filepath.Join(root,"preexecution.json")),&pre));if len(pre.Compact.Bindings)!=6{panic("six model bindings required")}
 calls,cases,disjoint,progressCount,feedbackCount:=0,0,0,0,0;frontiers:=map[string]int{};resources:=map[string]map[string][]float64{}
 for _,mode:=range []string{"expanded-fp32","expanded-ptq_ternary","expanded-qat_ternary","compact-fp32","compact-ptq_ternary","compact-qat_ternary"}{resources[mode]=map[string][]float64{}}
 for _,path:=range paths{
  dir:=filepath.Dir(path);var w struct{Observation bodyexecution.Observation `json:"observation"`;Parent []byte `json:"parent_receipt_bytes"`;Receipt json.RawMessage `json:"completeness_receipt"`}
  must(json.Unmarshal(read(path),&w));r,e:=completeness.Decode(w.Receipt);must(e)
  parent,e:=completeness.Decode(w.Parent);must(e)
  native,p,e:=bodyexecution.DecodeGeneration(read(filepath.Join(dir,"generation.json")));must(e)
  b,e:=json.Marshal(w.Observation);must(e);o:=w.Observation
  if !bytes.Equal(p,w.Parent)||o.ParentReceiptSHA256!=sha(p)||r.Scope["parent_receipt_sha256"]!=sha(p)||r.Scope["runtime_observation_sha256"]!=sha(b)||
   r.ProfileID!="gooo/typed-path-runtime-v1"||parent.FirstUnresolved==nil||parent.FirstUnresolved.ID!="execution_boundary"||r.FirstUnresolved==nil||r.FirstUnresolved.ID!="permission_boundary"||
   o.ProducerSourceSHA!="7db19b6bc9a2909aa059f1265d39a539c3573a57"||o.CompilerSourceSHA!=o.ProducerSourceSHA||o.OriginalSourceSHA256!=sha(read(filepath.Join(dir,"input.gooo")))||o.GeneratedSHA256!=sha([]byte(native.Source))||o.ActivityID!=native.Report.ActivityID||o.Stage!="COMPLETE"||len(o.Runs)!=2{panic("source/parent/runtime binding differs")}
  scope:=r.Scope["runtime_scope"].(map[string]any)
  if integer(scope["local_model_predictions"])!=0||integer(scope["external_provider_calls"])!=0{panic("runtime made provider calls")}
  axes:=map[string]completeness.CompletenessDimension{};for _,d:=range r.Dimensions{axes[d.ID]=d}
  for _,d:=range parent.Dimensions{
   if d.ID=="execution_boundary"||d.ID=="reverse_observation_coverage"{continue}
   left,_:=json.Marshal(d);right,_:=json.Marshal(axes[d.ID]);if !bytes.Equal(left,right){panic("unrelated parent axis changed")}
  }
  for _,id:=range []string{"runtime_source_replay","runtime_build","execution_boundary","runtime_deterministic_replay","reverse_observation_coverage","runtime_finite_accuracy"}{if axes[id].Status!="PASS"{panic("actual observed axis incomplete")}}
  if axes["runtime_finite_accuracy"].Numerator!=24||axes["runtime_finite_accuracy"].Denominator!=24||axes["reverse_observation_coverage"].Numerator!=24||axes["runtime_selection_disjointness"].Numerator!=8{panic("finite denominator differs")}
  suite,e:=bodyexecution.DecodeCases(read(filepath.Join(dir,"runtime-cases.json")));must(e)
  if len(o.Cases)!=len(suite){panic("case count differs")};for i,c:=range o.Cases{if c.Input!=suite[i].Input||c.Expected!=suite[i].Expected||c.Actual!=c.Expected||!c.Passed{panic("ordered actual mismatch")}}
  calls+=native.Report.BodyPaths.Search.Selection.ModelCalls;cases+=len(o.Cases);disjoint+=o.SelectionDisjointInputs;frontiers[r.FirstUnresolved.ID]++
  var row struct{Mode string `json:"mode"`;Cost struct{WallNS int64 `json:"wall_ns"`;UserNS int64 `json:"user_ns"`;SystemNS int64 `json:"system_ns"`} `json:"codegen_cost"`};must(json.Unmarshal(read(filepath.Join(dir,"observation.json")),&row))
  verifyChains(native.Report.BodyPaths.Progress,native.Report.BodyPaths.Feedback,pre.Compact.Bindings[row.Mode]);progressCount+=len(native.Report.BodyPaths.Progress);feedbackCount+=len(native.Report.BodyPaths.Feedback)
  sample:=resources[row.Mode];sample["codegen_ms"]=append(sample["codegen_ms"],float64(row.Cost.WallNS)/1e6)
  sample["model_prediction_ms"]=append(sample["model_prediction_ms"],float64(native.Report.BodyPaths.Search.Selection.Three.PredictNS)/1e6)
  for _,f:=range native.Report.BodyPaths.Feedback{if f.Three!=nil&&f.ModelCalls>0{sample["model_prediction_ms"]=append(sample["model_prediction_ms"],float64(f.Three.PredictNS)/1e6)}}
  sample["codegen_cpu_percent_one_core"]=append(sample["codegen_cpu_percent_one_core"],100*float64(row.Cost.UserNS+row.Cost.SystemNS)/float64(row.Cost.WallNS))
  sample["runtime_pipeline_ms"]=append(sample["runtime_pipeline_ms"],float64(o.ElapsedNS)/1e6)
  sample["build_ms"]=append(sample["build_ms"],float64(o.Build.WallNS)/1e6)
  for _,run:=range o.Runs{if !run.Completed||run.PeakRSSBytes==nil{panic("missing native resources")};sample["compiled_run_ms"]=append(sample["compiled_run_ms"],float64(run.WallNS)/1e6);sample["compiled_run_rss_mib"]=append(sample["compiled_run_rss_mib"],float64(*run.PeakRSSBytes)/(1<<20))}
 }
 summary:=map[string]any{}
 for mode,samples:=range resources{if len(samples["codegen_ms"])!=16{panic("mode denominator differs")};m:=map[string]any{};for name,v:=range samples{m[name+"_samples"]=len(v);m[name+"_median"]=median(v);m[name+"_nearest_rank_p95"]=v[(95*len(v)+99)/100-1]};summary[mode]=m}
 out:=map[string]any{"schema":"gooo/native-runtime-independent-consumption/v1","status":"PASS","compiler_source_sha":"7db19b6bc9a2909aa059f1265d39a539c3573a57","receipts":len(paths),"finite_expectations":cases,"selection_disjoint_expectations":disjoint,"model_predictions":calls,"runtime_model_predictions":0,"external_provider_calls":0,"first_unresolved_counts":frontiers,"resources":summary,"receipt_declaration":completeness.ContractBinding(),"scope":"Observed frozen source cohort, 16 requests per each of three variants and two representations in alternating pair order. Additional runtime inputs are independent of this selection suite only. No new optimizer update, training holdout, accuracy improvement, causal speedup or host CPU utilization claim."}
 out["verified_session_progress_records"]=progressCount;out["verified_feedback_records"]=feedbackCount
 out["timing_conditions"]="Local darwin/arm64, Go 1.27.1, fresh compiler subprocess per generation, alternating expanded/compact order per bilingual view. Build cache was cleaned immediately before this study; first native build includes cache effects. Model prediction timer excludes loading, process startup, source generation and native build. Compiled-run RSS is the generated program, not model memory. No concurrent source builds ran during collection."
 must(json.NewEncoder(os.Stdout).Encode(out))
}
